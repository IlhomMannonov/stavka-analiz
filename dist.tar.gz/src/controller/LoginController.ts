import {NextFunction, Request, Response} from "express";


export const getAllProviders = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    // if
    // const {chat_id} = req.query;
    // if (!chat_id) throw new Error("chat_id");
}

